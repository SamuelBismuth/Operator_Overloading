var hierarchy =
[
    [ "CircularInt", "class_circular_int.html", null ],
    [ "runtime_error", null, [
      [ "NotDivisible", "class_not_divisible.html", null ]
    ] ]
];