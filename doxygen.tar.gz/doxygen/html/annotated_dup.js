var annotated_dup =
[
    [ "CircularInt", "class_circular_int.html", "class_circular_int" ],
    [ "NotDivisible", "class_not_divisible.html", "class_not_divisible" ]
];